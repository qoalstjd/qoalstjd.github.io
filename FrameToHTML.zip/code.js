// ============================================================
// Frame to HTML Exporter - FIXED VERSION
// ============================================================

figma.showUI(__html__, { width: 480, height: 660, title: "Frame to HTML Exporter" });

let selectedFrame = null;
let frameElements = [];
let isExporting = false;

// ── 초기화 ─────────────────────────────────────
function init() {
    const sel = figma.currentPage.selection;
    if (sel.length !== 1 || sel[0].type !== "FRAME") {
        figma.ui.postMessage({
            type: "ERROR",
            message: "프레임을 하나 선택한 후 실행해주세요.",
        });
        return;
    }

    selectedFrame = sel[0];
    frameElements = scanFrameChildren(selectedFrame);

    figma.ui.postMessage({
        type: "FRAME_SCANNED",
        frameName: selectedFrame.name,
        frameWidth: selectedFrame.width,
        frameHeight: selectedFrame.height,
        elements: frameElements.map((el) => ({
            id: el.id,
            name: el.name,
            type: el.type,
            y: Math.round(el.y),
            height: Math.round(el.height),
        })),
    });

    figma.on("selectionchange", onSelectionChange);
}

// ── 선택 변경 ────────────────────────────────
function onSelectionChange() {
    if (isExporting) return;

    const sel = figma.currentPage.selection;
    if (sel.length === 0) {
        figma.ui.postMessage({ type: "SELECTION_CLEARED" });
        return;
    }

    const node = sel[0];
    figma.ui.postMessage({
        type: "ELEMENT_SELECTED_UNKNOWN",
        id: node.id,
        name: node.name,
        nodeType: node.type,
    });
}

// ── 상대 좌표 계산 ────────────────────────────
function getRelativeRect(node, frame) {
    const nodeAbs = node.absoluteTransform;
    const frameAbs = frame.absoluteTransform;

    const x = nodeAbs[0][2] - frameAbs[0][2];
    const y = nodeAbs[1][2] - frameAbs[1][2];

    return {
        x,
        y,
        width: node.width,
        height: node.height,
    };
}

// ── 스캔 ──────────────────────────────────────
function scanFrameChildren(frame) {
    const elements = [];
    const seen = new Set();

    function walk(node, depth) {
        if (seen.has(node.id)) return;
        seen.add(node.id);

        if (depth > 2) return;
        if ("visible" in node && !node.visible) return;

        const rect = getRelativeRect(node, frame);

        elements.push({
            id: node.id,
            name: node.name,
            type: node.type,
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height,
            node,
        });

        if ("children" in node && depth < 2) {
            for (const child of node.children) {
                walk(child, depth + 1);
            }
        }
    }

    for (const child of frame.children) {
        walk(child, 0);
    }

    elements.sort((a, b) => a.y - b.y);

    return elements;
}

// ── 메시지 ────────────────────────────────────
figma.ui.onmessage = async (msg) => {
    console.log(msg);
    switch (msg.type) {
        case "FOCUS_NODE": {
            const node = await figma.getNodeByIdAsync(msg.id);
            if (node) {
                figma.currentPage.selection = [node];
                figma.viewport.scrollAndZoomIntoView([node]);
            }
            break;
        }

        case "UPDATE_BUTTONS": {
            const btns = msg.buttons || [];
            for (const el of frameElements) {
                const found = btns.find((b) => b.id === el.id);
                el.isButton = !!found;
                el.link = found && found.link ? found.link : null;
            }
            break;
        }

        case "EXPORT": {
            isExporting = true;
            const folderName = msg.folderName || "output";
            // msg.buttons를 직접 사용 — frameElements 매칭 불필요
            const rawButtons = (msg.buttons || []).filter((b) => b.link && b.link.trim());

            try {
                await runExport(folderName, rawButtons);
            } catch (e) {
                figma.ui.postMessage({
                    type: "EXPORT_ERROR",
                    message: String(e),
                });
            } finally {
                isExporting = false;
            }
            break;
        }

        case "CLOSE":
            figma.closePlugin();
            break;
    }
};

// ── export ─────────────────────────────────────
async function runExport(folderName, rawButtons) {
    if (!selectedFrame) {
        throw new Error("선택된 Frame이 없습니다.");
    }

    const frameW = selectedFrame.width;
    const frameH = selectedFrame.height;

    // rawButtons에 좌표가 없으면 figma에서 직접 조회
    const buttonInfos = [];
    for (const b of rawButtons) {
        let x = b.x,
            y = b.y,
            width = b.width,
            height = b.height;

        // 좌표가 없는 경우 노드에서 직접 가져옴
        if (x == null || y == null) {
            const node = await figma.getNodeByIdAsync(b.id);
            if (!node) continue;
            const rect = getRelativeRect(node, selectedFrame);
            x = rect.x;
            y = rect.y;
            width = rect.width;
            height = rect.height;
        }

        buttonInfos.push({
            name: b.name || b.id,
            link: b.link.trim(),
            x,
            y,
            width,
            height,
        });
    }

    const slices = buildSlices(frameH);
    const exportedFiles = [];

    for (const slice of slices) {
        const sliceNode = figma.createSlice();
        sliceNode.x = selectedFrame.x;
        sliceNode.y = selectedFrame.y + slice.yStart;
        sliceNode.resize(frameW, Math.max(1, slice.height));
        figma.currentPage.appendChild(sliceNode);

        try {
            const bytes = await sliceNode.exportAsync({
                format: "PNG",
                constraint: { type: "SCALE", value: 1 },
            });

            exportedFiles.push({
                filename: slice.filename,
                bytes: Array.from(bytes),
                yStart: slice.yStart,
                height: slice.height,
            });
        } finally {
            sliceNode.remove();
        }
    }

    const html = generateHTML(exportedFiles, buttonInfos, frameW, frameH);

    figma.ui.postMessage({
        type: "EXPORT_DONE",
        folderName,
        files: exportedFiles,
        html,
    });
}

// ── slice ──────────────────────────────────────
function buildSlices(frameH) {
    const MAX_H = 2000;
    const slices = [];
    if (!frameH || frameH <= 0) return slices;
    let pos = 0,
        idx = 1,
        rem = frameH;

    while (rem > 0) {
        const h = Math.min(rem, MAX_H);
        slices.push({
            yStart: pos,
            height: h,
            filename: `img_${String(idx++).padStart(2, "0")}.png`,
        });
        pos += h;
        rem -= h;
    }
    return slices;
}

// ── HTML ───────────────────────────────────────
function generateHTML(files, buttonInfos, frameW, frameH) {
    const imgLines = files.map((f) => `  <img src="./${f.filename}" alt="" class="eventImg">`);

    const btnLines = buttonInfos.map((b) => {
        const top = ((b.y / frameH) * 100).toFixed(4);
        const left = ((b.x / frameW) * 100).toFixed(4);
        const w = ((b.width / frameW) * 100).toFixed(4);
        const h = ((b.height / frameH) * 100).toFixed(4);

        return `<button class="eventBtn" onclick="${b.link}" style="top:${top}%;left:${left}%;width:${w}%;height:${h}%;"></button>`;
    });

    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<!-- ▼ 복사 영역(게시글 업로드) 시작 -->
<style>
#eventWrap { position: relative; max-width: 800px; margin: 0 auto; font-size: 0; } 
#eventWrap * { box-sizing: border-box; margin: 0; padding: 0; } 
#eventWrap .eventImg { width: 100%; display: block; } 
#eventWrap .eventBtn { position: absolute; display: block; background: none; border: none; pointer-events: all; } 
</style>
<div id="eventWrap">
${imgLines.join("\n")}
${btnLines.join("\n")}
</div>
</body>
<!-- ▲ 복사 영역(게시글 업로드) 끝 -->
</html>`;
}

init();
